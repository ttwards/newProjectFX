package com.sokoban.controllers;

public class Target extends StaticShape{
    public Target(double x, double y) {
        super(x, y, "/images/black.png");
    }
}
