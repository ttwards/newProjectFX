package com.sokoban.controllers;
public class Wall extends StaticShape{
    public Wall(double x, double y) {
		super(x, y, "/images/white.png");
    }
}

