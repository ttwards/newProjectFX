package com.sokoban.controllers;
public class Null extends StaticShape{
    public Null(double x, double y) {
        super(x, y, "/images/red.png");
    }
}

