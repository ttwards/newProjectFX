package com.sokoban.controllers;
public class Empty extends StaticShape {
    public Empty(double x, double y) {
        super(x, y, "/images/blue.png");
    }
}